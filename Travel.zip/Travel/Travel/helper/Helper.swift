//
//  Helper.swift
//  Travel
//
//  Created by Kamil Vakhobov on 1.10.22.
//

import Foundation

func delay(durationInSeconds seconds: Double, completion: @escaping () -> Void){
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: completion )
}
