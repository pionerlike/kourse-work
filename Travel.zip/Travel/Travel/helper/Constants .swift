//
//  Constants .swift
//  Travel
//
//  Created by Kamil Vakhobov on 1.10.22.
//

import Foundation

struct K {
    
    struct ReuseIdentifier {
        static let onboardingCollectionViewCell = "cellId"
    }
    
    struct NavigationTitle {
        static let settings = "Settings"
        static let home = "Home"
    }
     
    struct Segue {
        static let showOnboarding = "showOnboarding"
        static let showLoginSignup = "showLoginSignup"
    }
    struct StoryBoardId {
        static let main = "Main"
        static let mainTabBarController = "MainTabBarController"
        static let onboardingViewController = "OnboardingViewController"
    }
}
