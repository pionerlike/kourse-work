//
//  homeViewController.swift
//  Travel
//
//  Created by Kamil Vakhobov on 3.11.22.
//

import UIKit
import MapKit
import FirebaseAuth

class HomeViewController: UIViewController {
     

    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
            

        
        let sourceLocation = CLLocationCoordinate2D(latitude: 53.9299856, longitude: 27.5889112)
        let destinationLocation = CLLocationCoordinate2D(latitude: 53.912227, longitude: 27.594343)

        addPin()
        createPath(sourceLocation: sourceLocation, destinationLocation: destinationLocation)
        self.mapView.delegate = self
    }
    
    func addPin() {
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 53.917708, longitude: 27.594970)
        annotation.title = "Bsuir First Campus"
        annotation.subtitle = "st. Petrusya Brovki 6"
        self.mapView.addAnnotation(annotation)
        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = CLLocationCoordinate2D(latitude: 53.911553, longitude: 27.595985)
        annotation2.title = "Bsuir Fifth Campus"
        annotation2.subtitle = "st. Platonova 39, Minsk"
        self.mapView.addAnnotation(annotation2)
        let annotation3 = MKPointAnnotation()
        annotation3.coordinate = CLLocationCoordinate2D(latitude: 53.9166691, longitude: 27.5961723)
        annotation3.title = "Bsuir Third Campus"
        annotation3.subtitle = "st. Petrusya Brovki 10"
        self.mapView.addAnnotation(annotation3)
        let annotation4 = MKPointAnnotation()
        annotation4.coordinate = CLLocationCoordinate2D(latitude: 53.918599, longitude: 27.593955)
        annotation4.title = "Bsuir Second Campus"
        annotation4.subtitle = "Minsk, st. Petrusya Brovka, 4"
        self.mapView.addAnnotation(annotation4)
        
    }
    
    func createPath(sourceLocation : CLLocationCoordinate2D, destinationLocation : CLLocationCoordinate2D){
        let sourcePlaceMark = MKPlacemark(coordinate: sourceLocation, addressDictionary: nil)
        let destinationPlaceMark = MKPlacemark(coordinate: destinationLocation, addressDictionary: nil)

        
        let sourceMapItem = MKMapItem(placemark: sourcePlaceMark)
        let destinationItem = MKMapItem(placemark: destinationPlaceMark)
        
        let sourceAnotation = MKPointAnnotation()
        sourceAnotation.title = "Dormitory"
        sourceAnotation.subtitle = "Minsk"
        if let location = sourcePlaceMark.location{
            sourceAnotation.coordinate = location.coordinate
        }
        
        let destinationAnotation = MKPointAnnotation()
        destinationAnotation.title = "Bsuir Second Campus"
        destinationAnotation.subtitle = "Minsk"
        if let location = destinationPlaceMark.location {
            destinationAnotation.coordinate = location.coordinate
        }

        
        self.mapView.showAnnotations([sourceAnotation, destinationAnotation], animated: true)
        
        let directionRequest = MKDirections.Request ()
        directionRequest.source = sourceMapItem
        directionRequest.destination = destinationItem
        directionRequest.transportType = .walking
        
        let direction = MKDirections(request: directionRequest)
        
        direction.calculate { (response, error) in
            guard let response = response else {
                if let error = error {
                    print("ERROR FOUND : \(error.localizedDescription)")
                }
                return
            }
            let route = response.routes[0]
            self.mapView.addOverlay(route.polyline, level: MKOverlayLevel.aboveRoads)
            
            let rect = route.polyline.boundingMapRect
            
            self.mapView.setRegion(MKCoordinateRegion(rect), animated: true)
        }
    }
    
}
extension HomeViewController: MKMapViewDelegate{
    public func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let rendere = MKPolylineRenderer(overlay: overlay)
        rendere.lineWidth = 5
        rendere.strokeColor = .systemGreen
        
        return rendere
        
        
    }

}
