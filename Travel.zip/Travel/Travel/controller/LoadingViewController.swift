//
//  LoadingViewController.swift
//  Travel
//
//  Created by Kamil Vakhobov on 29.09.22.
//

import UIKit
import FirebaseAuth



class LoadingViewController: UIViewController{
    
    
    private var isUserLoggedIn: Bool {
        return Auth.auth().currentUser != nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        delay(durationInSeconds: 2.0) {
            self.showInitialView()
        }
    }
    private func showInitialView (){
        if isUserLoggedIn {
            PresenterManager.shared.show(vc: .mainTabBarController)
            } else {
            performSegue(withIdentifier: K.Segue.showOnboarding, sender: nil)
        }
        
    }
}

 
